module.exports =
[
    {
      "userName": "sly",
      "password": "test",
      "email": "tylerstraffon@gmail.com",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "userName": "dzul",
      "password": "test",
      "email": "dylanstraffon@gmail.com",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    }
];