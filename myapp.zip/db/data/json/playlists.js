module.exports =[
    {
      "id": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "name": "numero uno",
      "memberId": "sly",
      "public": true,
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "766bb2ff-e694-411c-9adf-8c3df3476af4",
      "name": "dope blocks soap box",
      "memberId": "sly",
      "public": true,
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "304e4965-6890-4342-bb13-1f7180cc85e0",
      "name": "warm vibes",
      "memberId": "dzul",
      "public": true,
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "de91491d-916b-4b0d-b194-4995a65e81cd",
      "name": "cold vibes",
      "memberId": "dzul",
      "public": true,
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    }
];