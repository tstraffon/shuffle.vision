module.exports =
[
    {
      "phraseId": "28718ba6-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "30fc509e-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "3daf18ee-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "42bfdf1c-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "4779275c-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "4bae6530-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "4fd39c84-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "7fc3d6ac-cccc-11e9-bea0-88e9fe785c3a",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "553437ba-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "766bb2ff-e694-411c-9adf-8c3df3476af4",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "5ad54a7e-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "766bb2ff-e694-411c-9adf-8c3df3476af4",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "5f8ac9c2-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "766bb2ff-e694-411c-9adf-8c3df3476af4",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "64b158bc-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "304e4965-6890-4342-bb13-1f7180cc85e0",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "phraseId": "69cf28ba-cccc-11e9-bea0-88e9fe785c3a",
      "playlistId": "de91491d-916b-4b0d-b194-4995a65e81cd",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    }
];