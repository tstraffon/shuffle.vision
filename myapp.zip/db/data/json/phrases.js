module.exports =
[
    {
      "id": "28718ba6-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "visitor center",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "30fc509e-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "tough customer",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "3daf18ee-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "run good",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "42bfdf1c-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "collateral",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "4779275c-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "window shopping",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "4bae6530-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "tail lights",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "4fd39c84-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "pockets",
      "memberId": "sly",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "553437ba-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "freedom from fear",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "5ad54a7e-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "recognized by secret signs",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "5f8ac9c2-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "shark smile",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "64b158bc-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "settle your accounts",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    },
    {
      "id": "69cf28ba-cccc-11e9-bea0-88e9fe785c3a",
      "phrase": "chemical vacation",
      "memberId": "dzul",
      "dateAdded": "9/1/2019",
      "lastUpdated": "9/1/2019"
    }
];