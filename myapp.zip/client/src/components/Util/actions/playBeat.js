const addToCart = beat => {
    console.log("Playing Beat...", beat.name);
}

module.exports = addToCart;