# shuffle.vision
***
shuffle.vision is a web app designed to provide music production inspiration by shuffling different types inputted of media.
***

# Startup
***
`npm install`

`cd client`

`npm install`

`cd ..`

`npm run migrate`

`npm start`
