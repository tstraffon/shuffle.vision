const apiRouter = require('./routes/api');

module.exports = {
    apiRouter,
};
